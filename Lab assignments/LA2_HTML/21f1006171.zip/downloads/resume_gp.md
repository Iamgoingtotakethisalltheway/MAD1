## My resume
-------------
# Ganesh P  

## ID: 21f1006171  

### *About me: Footballer, mender, teacher, researcher, coder and data enthusiast.*  
  
-------------------------------------------

**Ganesh P | 2020 batch | copyright, 2022**
